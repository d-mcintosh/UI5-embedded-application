sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("myChildApp.myChildApp.controller.View1", {
		onInit: function () {

		}
	});
});